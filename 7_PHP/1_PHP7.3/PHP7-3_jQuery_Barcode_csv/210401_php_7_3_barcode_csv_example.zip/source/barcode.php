<html>
<head>
    <title>바코드 - CSV(Barcode - CSV / 생성 예제)</title>
    <meta charset="UTF-8">
    <script type="text/javascript" src="jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="jquery-barcode.js"></script>

   <style>
	.hello_table{
		border-spacing:0px;
		width:400px; 
		border-bottom:1px solid #666; 
		font-family: 'Nanum Gothic';
		font-size:13px;
	}

	.hello_table td{
		border-top:1px solid #666; 
		border-left:1px solid #666; 
		font-family: 'Nanum Gothic';
		font-size:13px;
		text-align:center;
	}

	.hello_table .td_right{
		border-right:1px solid #666; 
		font-family: 'Nanum Gothic';
		font-size:13px;
		text-align:center;
	}
    </style>
	
</head>
<body>

<?php
	$NUM = 0;
	$BARCODE = 1;
	$PRICE = 2;
	$FIRSTDATE = 3;
	$PRODUCTNAME = 4;
	$TYPEOFNAME = 5;
	$DESCRIPTION = 6;
?>

<?php
$row = 1;
$barcode_creation = 0;

if (($handle = fopen("php_barcode_csv_example.csv", "r")) !== FALSE) {

    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
	
	$num = count($data);
	
	if ($row == 1){
	        // echo "<p> $num fields in line $row: <br /></p>\n";
	        $barcode_creation = 1;
	}else{

	/*
  	            for ($c=0; $c < $num; $c++) {
 		           echo $data[$c] . "---" . $c ."---" . "<br />\n";
	            }
	*/
?>

<table class="hello_table">
	<tr>	
		<td style="width:70px">관리번호</td>
		<td style="width:120px;">
			<?php 
				echo iconv("EUC-KR", "UTF-8", $data[$NUM]);
			?>
		</td>
		<td style="width:100px">취득(구매)단가</td>
		<td class="td_right">
			<?php 
				echo $data[$PRICE];
			?>
		</td>
	</tr>
	<tr>	
		<td style="width:70px">품명</td>
		<td>
			<?php 
				echo iconv("EUC-KR", "UTF-8", $data[$PRODUCTNAME]);
			?>
		</td>
		<td style="width:100px">취득(구매)일자</td>
		<td class="td_right">
			<?php 
				echo $data[$FIRSTDATE];
			?>
		</td>
	</tr>
	<tr>	
		<td style="width:70px">규격명</td>
		<td class="td_right" colspan="3">
			<?php 
				echo iconv("EUC-KR", "UTF-8", $data[$TYPEOFNAME]);
			?>
		</td>
	</tr>
	<tr>	
		<td style="width:70px">비고</td>
		<td class="td_right" colspan="4">
			<?php 
				echo iconv("EUC-KR", "UTF-8", $data[$DESCRIPTION]);
			?>
		</td>
	</tr>
	<tr>	
		<td style="width:70px">바코드</td>
		<td class="td_right" colspan="4"><div id="bcTarget<?php echo $row; ?>" style="margin-top:5px;"></div>
		</td>
	</tr>
</table>

	<!-- 스크립트 시작(BEGIN JAVASCRIPT) -->
	<script type="text/javascript">
		$("#bcTarget<?php echo $row; ?>").barcode("<?php echo $data[$BARCODE]; ?>", "code128");
	</script>
<?
	}
	$row++;  
    }
    fclose($handle);
}
?>

<!--
<div id="bcTarget1" style="margin-top:30px;"></div>
<div id="bcTarget2" style="margin-top:30px;"></div>
<div id="bcTarget3" style="margin-top:30px;"></div>
<div id="bcTarget4" style="margin-top:30px;"></div>
<div id="bcTarget5" style="margin-top:30px;"></div>
-->
</body>

<script type="text/javascript">
/*	$("#bcTarget1").barcode("hello1234567", "code128");
	$("#bcTarget2").barcode("1234567890128", "ean13",{barWidth:2, barHeight:30});
	$("#bcTarget3").barcode("1234567", "int25",{barWidth:2, barHeight:30});	
	$("#bcTarget4").barcode("1234567890128", "code128",{barWidth:1, barHeight:70,showHRI:true,bgColor:"red"});
	$("#bcTarget5").barcode("1234567890128", "datamatrix",{showHRI:false,bgColor:"yellow"});
*/	
</script>
</html>